# Movie-ticket-booking-application
Back end -> SpringBootJava , Front End -> Angular , Database -> MySQL
